#pragma once
#ifndef __LAB1_GLUT_FUNCTIONS_H__
#define __LAB1_GLUT_FUNCTIONS_H__

extern void GLUTCALLBACK glutDisplay(void);
#endif