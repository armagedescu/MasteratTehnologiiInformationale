#pragma once
#ifndef __LAB1_EXTERNALS_H__
#define  __LAB1_EXTERNALS_H__
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <GL/glaux.h>
#include <stdio.h>
#include "glFunctions.h"


extern void CALLBACK resize(int width, int height);


extern void spacePrepare();

#endif