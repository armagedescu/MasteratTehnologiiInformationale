#pragma comment(lib,"OpenGL32.lib")
#pragma comment(lib,"Glu32.lib")
#pragma comment(lib,"Glut32.lib")
#pragma comment(lib,"Glaux.lib")